--dict_notification table
 
dict_notification = {
    ["1"] = {id = "1", type = "1", condition = {days = {3,7,15,30,40,50}}, content = "Bigger winnings and riches are waiting for you! Come get it now!"},
    ["2"] = {id = "2", type = "2", condition = {interval_hours = 2}, content = "Your hourly bonus is right here! Come and get it!"},
    ["3"] = {id = "3", type = "3", condition = {interval_hours = 2}, content = "The Lucky wheel is waiting for you! Spin and Win BIG!"}
}

    

