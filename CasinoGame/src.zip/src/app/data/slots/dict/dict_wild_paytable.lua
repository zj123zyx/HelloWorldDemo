--dict_wild_paytable table
 
dict_wild_paytable = {
    ["1000"] = {settle_type = "1000", multiple = "1"},
    ["1001"] = {settle_type = "1001", multiple = "2"},
    ["1002"] = {settle_type = "1002", multiple = "3"},
    ["1003"] = {settle_type = "1003", multiple = "5"}
}

    

