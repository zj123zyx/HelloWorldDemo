--dict_scene_cd table
 
dict_scene_cd = {
    ["1"] = {id = "1", fishtype_Id = "7", cd_value = "3000000"}
}

    

