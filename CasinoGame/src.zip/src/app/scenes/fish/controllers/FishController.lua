-----------------------------------------------------------
-- FishController 
-----------------------------------------------------------
local FishController = class("FishController", function()
        return display.newNode()
end)

function FishController:ctor( homeinfo )

    local ViewClass = require("app.scenes.fish.views.FishView")
    self.fishView =  ViewClass.new(self)
    self.fishView:init(homeinfo)
    self.fishView:addTo(self)

    self:setNodeEventEnabled(true)
    self:setTouchEnabled(true)
    -- self:addNodeEventListener(cc.NODE_TOUCH_EVENT, function (event)
    --         return self:onTouch_(event)
    --     end)

    -- 初始化鱼群控制参数(测试性能) jjf
    self.minCnt = 80
    self.maxCnt = 120
    self.fishTime = 0

    self.throwingBomb = false

    self.switchWeapon = false
    self.switchWeaponTime = 0
    self.switchWeaponCD = 0
    self.weaponsCache={}

    self.pathConfigId = DICT_FISH_SCENE["1"].path_Id

    PathPool.loadPath()

    self:registerUIEvent()
    --self:init()
end

function FishController:update(dt)

    -- 控制换武器CD jjf
    if self.switchWeapon == true then
        self.switchWeaponTime = self.switchWeaponTime  + dt
        if self.switchWeaponTime > self.switchWeaponCD then
            self.switchWeapon = false
            self.switchWeaponTime = 0
        end
    end

    -- 控制鱼群的最小数量 jjf
    while self.fishView.fishNode:getChildrenCount() < self.minCnt do
        local pathId = SceneManager.buildPath(self.pathConfigId)
        local clusterId = SceneManager.buildClusterByPathId(pathId)
        SceneManager.createFishCluster(pathId, clusterId, self.fishView.fishNode)
    end

    -- 控制鱼群的最大数量 jjf
    self.fishTime = self.fishTime + dt
    if  self.fishTime > 1.0 then
        self.fishTime = 0

        if self.fishView.fishNode:getChildrenCount() < self.maxCnt and math.newrandom() > 0.5 then
            local pathId = SceneManager.buildPath(self.pathConfigId)
            local clusterId = SceneManager.buildClusterByPathId(pathId)
            SceneManager.createFishCluster(pathId, clusterId, self.fishView.fishNode)
        end
    end
end

-- function FishController:init()

--     local cluster ={id="000201",name="小金鱼2条A*",delayTime=1000,pathId="4",speed=0,loop="0",fishKey="1",
--     fishcluster={
--         { id="13",resId="1",offsetY=-40,offsetX=10},
--         { id="101",resId="1",offsetY=0,offsetX=60},
--         { id="102",resId="1",offsetY=40,offsetX=10},
--         }
--     }

--     PathPool.addPath(4)

--     for i=1,#cluster.fishcluster do

--         local fishData = cluster.fishcluster[i]

--         local fish = FishManager.create(fishData.id)

--         fish.offset.x = fishData.offsetX * display.width/768
--         fish.offset.y = fishData.offsetY * display.height/560

--         local path = PathPool.getPath( cluster.pathId, 0)

--         fish:setRoute(path,0)
        
--         self.fishNode:addChild(fish)

--     end


--     local cluster ={id="000201",name="小金鱼2条A*",delayTime=1000,pathId="111",speed=0,loop="0",fishKey="1",
--     fishcluster={
--             { id="103",resId="1",offsetY=-40,offsetX=10},
--             { id="201",resId="1",offsetY=0,offsetX=60},
--             { id="202",resId="1",offsetY=40,offsetX=10},
--         }
--     }

--     PathPool.addPath(111)

--     local path=PathPool.getPath( cluster.pathId, 0)

--     for i=1,#cluster.fishcluster do

--         local fishData = cluster.fishcluster[i]

--         local fish = FishManager.create(fishData.id)

--         fish.offset.x = fishData.offsetX-- * display.width/768
--         fish.offset.y = fishData.offsetY-- * display.height/560

--         fish:setRoute(path,0)
        
--         self.fishNode:addChild(fish)

--     end


--     for i=1, #path.pointList do
--         local pt=path.pointList[i]
--         local ptSp = display.newSprite("#share_messagehint.png")
--         ptSp:setPosition(pt.x, pt.y)
--         ptSp:setScale(0.2)
        
--         self.fishNode:addChild(ptSp)

--     end

--     local cluster ={id="000201",name="小金鱼2条A*",delayTime=1000,pathId="9105",speed=0,loop="0",fishKey="1",
    
--     fishcluster={
--         { id="39",resId="1",offsetY=-40,offsetX=10},
--         { id="41",resId="1",offsetY=0,offsetX=60},
--         { id="42",resId="1",offsetY=40,offsetX=10},
--         }
--     }

--     PathPool.addPath(9105)

--     for i=1,#cluster.fishcluster do

--         local fishData = cluster.fishcluster[i]

--         local fish = FishManager.create(fishData.id)

--         fish.offset.x = fishData.offsetX * display.width/768
--         fish.offset.y = fishData.offsetY * display.height/560

--         local path = PathPool.getPath( cluster.pathId, 0)

--         fish:setRoute(path,0)
        
--         self.fishNode:addChild(fish)

--     end
-- end

function FishController:registerUIEvent()

    -- 切换武器(+) jjf
    core.displayEX.newButton(self.fishView.addBetBtn):onButtonClicked(function() 

        -- 判断换武器状态标识
        if self.switchWeapon == true then return end

        local level = app:getObject("FishModel"):getWeaponLevel() + 1
        if level <= 8 then

            -- 判断当前的金额是否足够发射炮弹
            if app:getUserModel():getGems() < tonumber(DICT_WEAPON[tostring(level)].bet) then
                scn.ScnMgr.popView("ShortCoinsView", {})
            else
                app:getObject("FishModel"):setWeaponLevel(level)
                self.switchWeaponCD = self.fishView:changeWeapon(level)
                self.switchWeapon = true
            end
        end
    end)

    -- 切换武器(-) jjf
    core.displayEX.newButton(self.fishView.subBetBtn):onButtonClicked(function() 

        -- 判断换武器状态标识
        if self.switchWeapon == true then return end

        local level = app:getObject("FishModel"):getWeaponLevel() - 1
        if level >= 1 then
            app:getObject("FishModel"):setWeaponLevel(level)
            self.switchWeaponCD = self.fishView:changeWeapon(level)
            self.switchWeapon = true
        end
    end)

    core.displayEX.newButton(self.fishView.paytableBtn):onButtonClicked(function()
        local ccbi = "fish/fishing_hawaii/paytable_hawaii.ccbi"
        scn.ScnMgr.addView("PaytableView",{ccbi = ccbi, scroll=true})
    end)

    core.displayEX.newButton(self.fishView.item1Btn)
        :onButtonClicked(function()
            scn.ScnMgr.addView("CommonTip",{ok_callback = function()

                    local totalGems = app:getUserModel():getGems()
                    if totalGems >= 5 then
                        app:getUserModel():setGems(totalGems-5)
                        self.throwingBomb = true
                    else
                        scn.ScnMgr.popView("ShortGemsView",{})
                    end

                end,
                title="Throwing Bomb",
                content="Cost 5 Gems, you will fishing biger fishes,Are you sure you want to throwing Bomb ?"})

        end)

    core.displayEX.newButton(self.fishView.item2Btn)
        :onButtonClicked(function()
                    end)

    self.fishView.item1Btn:setButtonEnabled(false)
    self.fishView.item2Btn:setButtonEnabled(false)
end

function FishController:onTouch_(event)

    if event.name == "began" then
        self.time = 0

        if event.x < 80 then return true end
        if event.y < 100 then return true end

        if event.x > display.width - 80 then return true end
        if event.y > display.height - 80 then return true end

        if self.throwingBomb == true then

            local destPos = {x=event.x, y=event.y}

            local bombEffect  = CCBReaderLoad("fish/effect/bomb_explore.ccbi", self)

            bombEffect:setPosition(destPos)

            self.fishView.effectNode:addChild(bombEffect)

            self:performWithDelay(function()
                bombEffect:removeFromParent(false)
            end,1.0)

            self.throwingBomb = false

            return true
        end


        local weaponLevel = app:getObject("FishModel"):getWeaponLevel()
        local b_dict = DICT_WEAPON[tostring(weaponLevel)]

        if app:getUserModel():getCoins() < tonumber(b_dict.bet) then
            scn.ScnMgr.popView("ShortCoinsView",{})
        else
            local destPos = {x=event.x, y=event.y}
            self.fishView:changeDirection(destPos,function()

                local weaponPos = self.fishView:getWeaponPos()
                local startPos = {x=weaponPos.x, y=weaponPos.y}

                local weapon=Weapon.new(weaponLevel)
                weapon:init(startPos, destPos)
                weapon:start()
                self.fishView.fishNode:addChild(weapon)
            end)
        end


    elseif event.name == "ended" then
        
    end

    return true
end

function FishController:getUnusedWeapon(level)

    local weapons = self.weaponsCache[level]

    if weapons then

        for i=1,#weapons do
            local weapon = weapons[i]

            if weapon.inuse == false then
                weapon.inuse = true
                return weapon
            end

        end    
    else
        weapons = {}
        self.weaponsCache[level] = weapons
    end
    
    local weapon=Weapon.new(level)
    weapon.inuse = true

    table.insert(weapons, weapon)

    return weapon
end

function FishController:lockUI()
    --self.controlbarView.addGemsBtn:setButtonEnabled(false)
    --self.controlbarView.addCoinsBtn:setButtonEnabled(false)
    --self.controlbarView.subBetBtn:setButtonEnabled(false)
    --self.controlbarView.addBetBtn:setButtonEnabled(false)
    --self.controlbarView:lockBTN()
end

function FishController:unLockUI()
    --self.controlbarView.addGemsBtn:setButtonEnabled(true)
    --self.controlbarView.addCoinsBtn:setButtonEnabled(true)
    --self.controlbarView.subBetBtn:setButtonEnabled(true)
    --self.controlbarView.addBetBtn:setButtonEnabled(true)
    --self.controlbarView:unlockBTN()
end

function FishController:onEnter()
end

function FishController:onExit() 
end

return FishController
