--dict_facebook_feed table
 
dict_facebook_feed = {
    ["1"] = {id = "1", desc = "邀请玩家", content = {link="https://itunes.apple.com/app/id882438707",picture="http://122.0.71.122/static/casino/img/250.jpg",name="New Vegas Casino",caption="New Vegas Casino brings to you an incredible long-term win experience that you won’t miss out, and yes, more themes are coming one by one!",description="New Vegas Casino brings to you an incredible long-term win experience that you won’t miss out, and yes, more themes are coming one by one!"}}
}

    

