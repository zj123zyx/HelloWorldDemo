if nil == sp then
    return
end

sp.EventType =
{
    ANIMATION_START = 0, 
    ANIMATION_END = 1, 
    ANIMATION_COMPLETE = 2, 
    ANIMATION_EVENT = 3,
}
