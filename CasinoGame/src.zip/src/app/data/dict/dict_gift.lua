--dict_gift table
 
dict_gift = {
    ["1"] = {gift_id = "1", type = "1", name = "200 coins", desc = "200 Coins for you", item_id = "1000", item_cnt = "200", life_time = {1,10}, picture = "liwu_tubiao_jinbi.png", currency = "1000", price = "0", vipLevel = "0"},
    ["2"] = {gift_id = "2", type = "1", name = "2 gems", desc = "2 Gems for you", item_id = "1000", item_cnt = "2", life_time = {1,10}, picture = "liwu_tubiao_baoshi.png", currency = "1000", price = "0", vipLevel = "0"},
    ["3"] = {gift_id = "3", type = "2", name = "Rose", desc = "A lovely rose", item_id = "1003", item_cnt = "2", life_time = {3,1}, picture = "liwu_tubiao_flowers.png", currency = "1003", price = "1", vipLevel = "0"},
    ["4"] = {gift_id = "4", type = "2", name = "Egg", desc = "A egg for hurling", item_id = "1003", item_cnt = "2", life_time = {3,1}, picture = "liwu_tubiao_egg.png", currency = "1003", price = "2", vipLevel = "0"},
    ["5"] = {gift_id = "5", type = "2", name = "Beer", desc = "Cheers together", item_id = "1003", item_cnt = "2", life_time = {3,1}, picture = "liwu_tubiao_pijiu.png", currency = "1003", price = "1", vipLevel = "1"},
    ["6"] = {gift_id = "6", type = "2", name = "Tomatoes", desc = "A tomatoes for hurling", item_id = "1003", item_cnt = "2", life_time = {3,1}, picture = "liwu_tubiao_xihongshi.png", currency = "1003", price = "2", vipLevel = "1"},
    ["7"] = {gift_id = "7", type = "2", name = "Kiss", desc = "A lovely Kiss", item_id = "1003", item_cnt = "2", life_time = {3,1}, picture = "liwu_tubiao_kiss.png", currency = "1003", price = "1", vipLevel = "2"},
    ["8"] = {gift_id = "8", type = "2", name = "Dog", desc = "A mad dog", item_id = "1003", item_cnt = "2", life_time = {3,1}, picture = "liwu_tubiao_dog.png", currency = "1003", price = "2", vipLevel = "2"},
    ["9"] = {gift_id = "9", type = "2", name = "Juice", desc = "A cup of lemon juice", item_id = "1003", item_cnt = "2", life_time = {3,1}, picture = "liwu_tubiao_qishui.png", currency = "1003", price = "1", vipLevel = "3"},
    ["10"] = {gift_id = "10", type = "2", name = "Bomb", desc = "A huge power bomb", item_id = "1003", item_cnt = "2", life_time = {3,1}, picture = "liwu_tubiao_zadang.png", currency = "1003", price = "2", vipLevel = "3"}
}

    

