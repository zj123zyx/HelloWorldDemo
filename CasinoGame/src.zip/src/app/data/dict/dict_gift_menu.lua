--dict_gift_menu table
 
dict_gift_menu = {
    ["1"] = {menu_id = "1", name = "free gifts", sub_menu = "1", contain_gifts = {1,2}},
    ["2"] = {menu_id = "2", name = "gifts", sub_menu = "1", contain_gifts = {3,4,5,6,7,8,9,10}}
}

    

