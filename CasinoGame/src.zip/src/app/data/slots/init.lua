require "app.data.slots.DicConstants"
require "app.data.slots.DictUtil"
require "app.data.slots.DicConstants"
require "app.data.slots.calculation.ExperienceUtil"

local slots = {}

slots.MachineApi = import(".MachineApi")

return slots
