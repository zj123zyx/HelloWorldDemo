--dict_chip table
 
dict_chip = {
    ["1"] = {chip_id = "1", amount = "1", button = "chip_huibai.png", picture = "xie_chip_huibai.png"},
    ["2"] = {chip_id = "2", amount = "5", button = "chip_hongbai.png", picture = "xie_chip_hongbai.png"},
    ["3"] = {chip_id = "3", amount = "10", button = "chip_lanbai.png", picture = "xie_chip_lanbai.png"},
    ["4"] = {chip_id = "4", amount = "25", button = "chip_lvbai.png", picture = "xie_chip_lvbai.png"},
    ["5"] = {chip_id = "5", amount = "50", button = "chip_heibai.png", picture = "xie_chip_heibai.png"},
    ["6"] = {chip_id = "6", amount = "100", button = "chip_zibai.png", picture = "xie_chip_zibai.png"},
    ["7"] = {chip_id = "7", amount = "250", button = "chip_fenbai.png", picture = "xie_chip_fenbai.png"},
    ["8"] = {chip_id = "8", amount = "500", button = "chip_huangbai.png", picture = "xie_chip_huangbai.png"},
    ["9"] = {chip_id = "9", amount = "1000", button = "chip_shenlan.png", picture = "xie_chip_shenlan.png"},
    ["10"] = {chip_id = "10", amount = "2000", button = "chip_jvbai.png", picture = "xie_chip_jvbai.png"},
    ["11"] = {chip_id = "11", amount = "5000", button = "chip_caolvbai.png", picture = "xie_chip_caolvbai.png"},
    ["12"] = {chip_id = "12", amount = "10000", button = "chip_jvhei.png", picture = "xie_chip_jvhei.png"},
    ["13"] = {chip_id = "13", amount = "20000", button = "chip_zonghei.png", picture = "xie_chip_zonghei.png"},
    ["14"] = {chip_id = "14", amount = "50000", button = "chip_lanhei.png", picture = "xie_chip_lanhei.png"},
    ["15"] = {chip_id = "15", amount = "200000", button = "chip_honghei.png", picture = "xie_chip_honghei.png"}
}

    

