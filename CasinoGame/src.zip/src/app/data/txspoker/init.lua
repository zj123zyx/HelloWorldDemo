require "app.data.txspoker.TXSConstants"
local txspoker = {}


return txspoker
