--dict_freespin_paytable table
 
dict_freespin_paytable = {
    ["2000|3"] = {key = "2000|3", settle_type = "2000", symbol_cnt = "3", multiple = "5"},
    ["2000|4"] = {key = "2000|4", settle_type = "2000", symbol_cnt = "4", multiple = "10"},
    ["2000|5"] = {key = "2000|5", settle_type = "2000", symbol_cnt = "5", multiple = "15"},
    ["2000|6"] = {key = "2000|6", settle_type = "2000", symbol_cnt = "6", multiple = "15"},
    ["2001|3"] = {key = "2001|3", settle_type = "2001", symbol_cnt = "3", multiple = "10"},
    ["2001|4"] = {key = "2001|4", settle_type = "2001", symbol_cnt = "4", multiple = "15"},
    ["2001|5"] = {key = "2001|5", settle_type = "2001", symbol_cnt = "5", multiple = "20"},
    ["2001|6"] = {key = "2001|6", settle_type = "2001", symbol_cnt = "6", multiple = "30"},
    ["2002|3"] = {key = "2002|3", settle_type = "2002", symbol_cnt = "3", multiple = "5"},
    ["2002|4"] = {key = "2002|4", settle_type = "2002", symbol_cnt = "4", multiple = "10"},
    ["2002|5"] = {key = "2002|5", settle_type = "2002", symbol_cnt = "5", multiple = "20"},
    ["2002|6"] = {key = "2002|6", settle_type = "2002", symbol_cnt = "6", multiple = "20"}
}

    

