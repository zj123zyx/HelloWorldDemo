--dict_fish_scene table
 
dict_fish_scene = {
    ["1"] = {scn_Id = "1", ccb = "1", bigFish_time = "30000", bigFish_pathId1 = "4", bigFish_pathId2 = "14", bigFish_clusterId = "1;2;3;4;6", path_Id = "1", cd_Id = "1"},
    ["2"] = {scn_Id = "2", ccb = "2", bigFish_time = "30000", bigFish_pathId1 = "4", bigFish_pathId2 = "14", bigFish_clusterId = "1;2;3;4;6", path_Id = "1", cd_Id = "1"},
    ["3"] = {scn_Id = "3", ccb = "3", bigFish_time = "30000", bigFish_pathId1 = "4", bigFish_pathId2 = "14", bigFish_clusterId = "1;2;3;4;6", path_Id = "1", cd_Id = "1"},
    ["4"] = {scn_Id = "4", ccb = "4", bigFish_time = "30000", bigFish_pathId1 = "4", bigFish_pathId2 = "14", bigFish_clusterId = "1;2;3;4;6", path_Id = "1", cd_Id = "1"},
    ["5"] = {scn_Id = "5", ccb = "1", bigFish_time = "30000", bigFish_pathId1 = "4", bigFish_pathId2 = "14", bigFish_clusterId = "1;2;3;4;6", path_Id = "9", cd_Id = "1"},
    ["6"] = {scn_Id = "6", ccb = "1", bigFish_time = "30000", bigFish_pathId1 = "5004", bigFish_pathId2 = "5014", bigFish_clusterId = "1;2;3;5;6", path_Id = "10", cd_Id = "1"},
    ["7"] = {scn_Id = "7", ccb = "2", bigFish_time = "30000", bigFish_pathId1 = "5004", bigFish_pathId2 = "5014", bigFish_clusterId = "1;2;3;5;6", path_Id = "10", cd_Id = "1"},
    ["8"] = {scn_Id = "8", ccb = "3", bigFish_time = "30000", bigFish_pathId1 = "5004", bigFish_pathId2 = "5014", bigFish_clusterId = "1;2;3;5;6", path_Id = "10", cd_Id = "1"},
    ["9"] = {scn_Id = "9", ccb = "4", bigFish_time = "30000", bigFish_pathId1 = "5004", bigFish_pathId2 = "5014", bigFish_clusterId = "1;2;3;5;6", path_Id = "10", cd_Id = "1"},
    ["10"] = {scn_Id = "10", ccb = "1", bigFish_time = "30000", bigFish_pathId1 = "5004", bigFish_pathId2 = "5014", bigFish_clusterId = "1;2;3;5;6", path_Id = "11", cd_Id = "1"},
    ["11"] = {scn_Id = "11", ccb = "2", bigFish_time = "30000", bigFish_pathId1 = "5004", bigFish_pathId2 = "5014", bigFish_clusterId = "1;2;3;5;6", path_Id = "11", cd_Id = "1"},
    ["12"] = {scn_Id = "12", ccb = "3", bigFish_time = "30000", bigFish_pathId1 = "5004", bigFish_pathId2 = "5014", bigFish_clusterId = "1;2;3;7;8", path_Id = "11", cd_Id = "1"},
    ["13"] = {scn_Id = "13", ccb = "4", bigFish_time = "30000", bigFish_pathId1 = "5004", bigFish_pathId2 = "5014", bigFish_clusterId = "1;2;3;5;6", path_Id = "11", cd_Id = "1"},
    ["14"] = {scn_Id = "14", ccb = "1", bigFish_time = "30000", bigFish_pathId1 = "5004", bigFish_pathId2 = "5014", bigFish_clusterId = "1;2;3;5;6", path_Id = "12", cd_Id = "1"},
    ["15"] = {scn_Id = "15", ccb = "2", bigFish_time = "30000", bigFish_pathId1 = "5004", bigFish_pathId2 = "5014", bigFish_clusterId = "1;2;3;5;6", path_Id = "12", cd_Id = "1"},
    ["16"] = {scn_Id = "16", ccb = "3", bigFish_time = "30000", bigFish_pathId1 = "5004", bigFish_pathId2 = "5014", bigFish_clusterId = "1;2;3;7;8", path_Id = "12", cd_Id = "1"},
    ["17"] = {scn_Id = "17", ccb = "4", bigFish_time = "30000", bigFish_pathId1 = "5004", bigFish_pathId2 = "5014", bigFish_clusterId = "1;2;3;7;8", path_Id = "12", cd_Id = "1"}
}

    

