--dict_bonus_type table
 
dict_bonus_type = {
    ["1"] = {id = "1", bonus_type = "Open Boxes(3 lives)"},
    ["2"] = {id = "2", bonus_type = "Open Boxes(5 levels)"},
    ["3"] = {id = "3", bonus_type = "Match 3 "},
    ["4"] = {id = "4", bonus_type = "Journey"},
    ["5"] = {id = "5", bonus_type = "Monopoly"}
}

    

