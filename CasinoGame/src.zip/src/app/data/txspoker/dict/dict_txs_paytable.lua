--dict_txs_paytable table
 
dict_txs_paytable = {
    ["1"] = {id = "1", name = "Royal Straight Flush", multiple = "100"},
    ["2"] = {id = "2", name = "Straight Flush", multiple = "20"},
    ["3"] = {id = "3", name = "Four of a Kind", multiple = "10"},
    ["4"] = {id = "4", name = "Full house", multiple = "3"},
    ["5"] = {id = "5", name = "Flush", multiple = "2"},
    ["6"] = {id = "6", name = "Straight", multiple = "1"},
    ["7"] = {id = "7", name = "Three of a kind", multiple = "1"},
    ["8"] = {id = "8", name = "Two Pairs", multiple = "1"},
    ["9"] = {id = "9", name = "One Pair", multiple = "1"},
    ["10"] = {id = "10", name = "High Card", multiple = "1"}
}

    

