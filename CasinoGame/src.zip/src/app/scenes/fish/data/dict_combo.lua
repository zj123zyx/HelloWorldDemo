--dict_combo table
 
dict_combo = {
    ["1"] = {combo_Id = "1", weight = "1", reward_bet = "2", ccb = "3", requirement = "3"},
    ["2"] = {combo_Id = "2", weight = "2", reward_bet = "2", ccb = "4", requirement = "4"},
    ["3"] = {combo_Id = "3", weight = "3", reward_bet = "3", ccb = "5", requirement = "5"},
    ["4"] = {combo_Id = "4", weight = "4", reward_bet = "3", ccb = "6", requirement = "6"},
    ["5"] = {combo_Id = "5", weight = "5", reward_bet = "5", ccb = "7", requirement = "7"},
    ["6"] = {combo_Id = "6", weight = "6", reward_bet = "5", ccb = "8", requirement = "8"}
}

    

