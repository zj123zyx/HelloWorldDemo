--dict_daily_reward table
 
dict_daily_reward = {
    ["1"] = {login_days = "1", reward_type = "1000", reward_count = "200"},
    ["2"] = {login_days = "2", reward_type = "1003", reward_count = "4"},
    ["3"] = {login_days = "3", reward_type = "1000", reward_count = "300"},
    ["4"] = {login_days = "4", reward_type = "1003", reward_count = "8"},
    ["5"] = {login_days = "5", reward_type = "1000", reward_count = "500"},
    ["6"] = {login_days = "6", reward_type = "1000", reward_count = "1000"},
    ["7"] = {login_days = "7", reward_type = "1003", reward_count = "15"}
}

    

