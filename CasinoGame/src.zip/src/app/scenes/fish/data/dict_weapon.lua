--dict_weapon table
 
dict_weapon = {
    ["1"] = {ID = "1", name = "1号炮", speed = "260", distance = "350", range = "48", upper_limit = "4", switch_cd = "0", cooling_cd = "1100", bet = "1", ccb = "1"},
    ["2"] = {ID = "2", name = "2号炮", speed = "300", distance = "400", range = "55", upper_limit = "4", switch_cd = "0", cooling_cd = "1000", bet = "2", ccb = "2"},
    ["3"] = {ID = "3", name = "3号炮", speed = "340", distance = "450", range = "62", upper_limit = "5", switch_cd = "0", cooling_cd = "900", bet = "3", ccb = "3"},
    ["4"] = {ID = "4", name = "4号炮", speed = "380", distance = "500", range = "69", upper_limit = "5", switch_cd = "0", cooling_cd = "800", bet = "4", ccb = "4"},
    ["5"] = {ID = "5", name = "5号炮", speed = "420", distance = "550", range = "76", upper_limit = "6", switch_cd = "0", cooling_cd = "700", bet = "5", ccb = "5"},
    ["6"] = {ID = "6", name = "6号炮", speed = "460", distance = "600", range = "83", upper_limit = "6", switch_cd = "0", cooling_cd = "600", bet = "6", ccb = "6"},
    ["7"] = {ID = "7", name = "7号炮", speed = "500", distance = "650", range = "90", upper_limit = "7", switch_cd = "0", cooling_cd = "500", bet = "7", ccb = "7"},
    ["8"] = {ID = "8", name = "8号炮", speed = "800", distance = "700", range = "100", upper_limit = "10", switch_cd = "0", cooling_cd = "0", bet = "10", ccb = "8"},
    ["9"] = {ID = "9", name = "9号炮", speed = "1000", distance = "700", range = "50", upper_limit = "15", switch_cd = "0", cooling_cd = "0", bet = "15", ccb = "9"}
}

    

