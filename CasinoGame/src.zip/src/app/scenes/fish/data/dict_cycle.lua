--dict_cycle table
 
dict_cycle = {
    ["0"] = {id = "0", min_1_up = "13500", min_1_low = "11000", min_2_up = "14000", min_2_low = "10800", min_3_up = "14500", min_3_low = "10600", min_4_up = "15000", min_4_low = "10400", min_5_up = "15500", min_5_low = "10200", min_6_up = "16000", min_6_low = "10000", min_7_up = "10000", min_7_low = "9000", min_8_up = "10200", min_8_low = "9000", min_9_up = "10400", min_9_low = "8800", min_10_up = "10600", min_10_low = "8500", min_11_up = "10800", min_11_low = "8400", min_12_up = "11000", min_12_low = "8200"},
    ["1"] = {id = "1", min_1_up = "13500", min_1_low = "11000", min_2_up = "14000", min_2_low = "10800", min_3_up = "14500", min_3_low = "10600", min_4_up = "15000", min_4_low = "10400", min_5_up = "14500", min_5_low = "10200", min_6_up = "15000", min_6_low = "10000", min_7_up = "10000", min_7_low = "9000", min_8_up = "10200", min_8_low = "8800", min_9_up = "10400", min_9_low = "8600", min_10_up = "10600", min_10_low = "8400", min_11_up = "10800", min_11_low = "8000", min_12_up = "11000", min_12_low = "8000"},
    ["2"] = {id = "2", min_1_up = "13000", min_1_low = "10000", min_2_up = "13200", min_2_low = "10000", min_3_up = "13400", min_3_low = "9800", min_4_up = "13600", min_4_low = "9600", min_5_up = "13800", min_5_low = "9400", min_6_up = "14000", min_6_low = "9200", min_7_up = "10000", min_7_low = "7200", min_8_up = "10200", min_8_low = "7000", min_9_up = "10400", min_9_low = "7100", min_10_up = "10600", min_10_low = "6900", min_11_up = "10800", min_11_low = "6700", min_12_up = "11000", min_12_low = "6500"},
    ["3"] = {id = "3", min_1_up = "13000", min_1_low = "10000", min_2_up = "13200", min_2_low = "9800", min_3_up = "13400", min_3_low = "9600", min_4_up = "13600", min_4_low = "9400", min_5_up = "13800", min_5_low = "9200", min_6_up = "14000", min_6_low = "9000", min_7_up = "10000", min_7_low = "7000", min_8_up = "10200", min_8_low = "6800", min_9_up = "10400", min_9_low = "6600", min_10_up = "10600", min_10_low = "6400", min_11_up = "10800", min_11_low = "6200", min_12_up = "11000", min_12_low = "6000"}
}

    

