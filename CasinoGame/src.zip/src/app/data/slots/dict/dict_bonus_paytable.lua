--dict_bonus_paytable table
 
dict_bonus_paytable = {
    ["3000|3"] = {key = "3000|3", settle_type = "3000", symbol_cnt = "3", multiple = "1"},
    ["3000|4"] = {key = "3000|4", settle_type = "3000", symbol_cnt = "4", multiple = "2"},
    ["3000|5"] = {key = "3000|5", settle_type = "3000", symbol_cnt = "5", multiple = "3"},
    ["3001|3"] = {key = "3001|3", settle_type = "3001", symbol_cnt = "3", multiple = "1"},
    ["3001|4"] = {key = "3001|4", settle_type = "3001", symbol_cnt = "4", multiple = "3"},
    ["3001|5"] = {key = "3001|5", settle_type = "3001", symbol_cnt = "5", multiple = "5"},
    ["3002|3"] = {key = "3002|3", settle_type = "3002", symbol_cnt = "3", multiple = "1"},
    ["3002|4"] = {key = "3002|4", settle_type = "3002", symbol_cnt = "4", multiple = "5"},
    ["3002|5"] = {key = "3002|5", settle_type = "3002", symbol_cnt = "5", multiple = "20"},
    ["3003|3"] = {key = "3003|3", settle_type = "3003", symbol_cnt = "3", multiple = "1"},
    ["3003|4"] = {key = "3003|4", settle_type = "3003", symbol_cnt = "4", multiple = "5"},
    ["3003|5"] = {key = "3003|5", settle_type = "3003", symbol_cnt = "5", multiple = "10"},
    ["3004|3"] = {key = "3004|3", settle_type = "3004", symbol_cnt = "3", multiple = "1"},
    ["3004|4"] = {key = "3004|4", settle_type = "3004", symbol_cnt = "4", multiple = "6"},
    ["3004|5"] = {key = "3004|5", settle_type = "3004", symbol_cnt = "5", multiple = "20"},
    ["3005|3"] = {key = "3005|3", settle_type = "3005", symbol_cnt = "3", multiple = "1"},
    ["3005|4"] = {key = "3005|4", settle_type = "3005", symbol_cnt = "4", multiple = "3"},
    ["3005|5"] = {key = "3005|5", settle_type = "3005", symbol_cnt = "5", multiple = "8"}
}

    

