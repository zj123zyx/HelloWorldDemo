require "app.data.bj.BjConstants"
local blackjack = {}


return blackjack
