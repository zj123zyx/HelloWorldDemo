
DB={}

DB.CARD_NUM={1,2,3,4,5,6,7,8,9,10,11,12,13}

DB.CARD_TYPE={
    Spade=1,
    heart=2,
    club=3,
    diamond=4
}
DB.DOUBLE_TYPE={
    Spade=1,
    heart=2,
    club=3,
    diamond=4,
    red=5,
    black=6
}