--dict_view_priority table
 
dict_view_priority = {
    ["BonusWinView"] = {viewname = "BonusWinView", priority = "80"},
    ["BoostTaskView"] = {viewname = "BoostTaskView", priority = "25"},
    ["CharacterView"] = {viewname = "CharacterView", priority = "1"},
    ["CommonView"] = {viewname = "CommonView", priority = "1"},
    ["FBConnectView"] = {viewname = "FBConnectView", priority = "5"},
    ["FreeSpinWinView"] = {viewname = "FreeSpinWinView", priority = "1"},
    ["GiftsView"] = {viewname = "GiftsView", priority = "1"},
    ["HourlyBonusView"] = {viewname = "HourlyBonusView", priority = "1"},
    ["LevelUpView"] = {viewname = "LevelUpView", priority = "100"},
    ["MegawinView"] = {viewname = "MegawinView", priority = "90"},
    ["ProductsView"] = {viewname = "ProductsView", priority = "1"},
    ["RankingView"] = {viewname = "RankingView", priority = "1"},
    ["RateTaskView"] = {viewname = "RateTaskView", priority = "15"},
    ["ShowWinView"] = {viewname = "ShowWinView", priority = "30"},
    ["TaskCompleteView"] = {viewname = "TaskCompleteView", priority = "90"},
    ["UnLockMachineView"] = {viewname = "UnLockMachineView", priority = "20"},
    ["BonusGoView"] = {viewname = "BonusGoView", priority = "89"}
}

    

