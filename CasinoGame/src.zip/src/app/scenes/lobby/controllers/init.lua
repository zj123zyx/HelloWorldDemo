
-- init controllers
local cotors = {}

cotors.GameCotor = import(".GameController")

return cotors
