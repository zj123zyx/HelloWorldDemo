require "app.data.poker.DictPokerConstants"
local poker = {}

poker.PokerData = require("app.data.poker.PokerData")

return poker
