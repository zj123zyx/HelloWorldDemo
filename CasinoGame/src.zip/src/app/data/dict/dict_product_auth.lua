--dict_product_auth table
 
dict_product_auth = {
    ["132312816920175"] = {app_id = "132312816920175", product_ids = "1,2,3,4,5,6,7,8,9,10,11,12", desc = "universal版"},
    ["132312816920176"] = {app_id = "132312816920176", product_ids = "1,2,3,4,5,6,7,8,9,10,11,12", desc = "HD版"},
    ["132312816920177"] = {app_id = "132312816920177", product_ids = "13,14,15,16,17,18,19,20,21,22,23,24", desc = "android版"}
}

    

