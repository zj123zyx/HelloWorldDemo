
-- init models
local models = {}

--models.SlotsModel = import(".SlotsModel")
models.UserModel = import(".UserModel")

return models
