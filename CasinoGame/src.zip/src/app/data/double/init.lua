require "app.data.double.DoubleConstants"
local double = {}

double.DoubleGame = require("app.data.double.DoubleGame")

return double
