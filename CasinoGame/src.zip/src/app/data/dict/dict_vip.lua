--dict_vip table
 
dict_vip = {
    ["1"] = {level = "1", alias = "bronze", vip_point = "20", reward_id = "705", extra_coins_percent = "10", picture = "shengji_vip_tong.png"},
    ["2"] = {level = "2", alias = "silver", vip_point = "1000", reward_id = "706", extra_coins_percent = "50", picture = "shengji_vip_yin.png"},
    ["3"] = {level = "3", alias = "gold", vip_point = "10000", reward_id = "707", extra_coins_percent = "100", picture = "shengji_vip_jin.png"},
    ["4"] = {level = "4", alias = "platinum", vip_point = "50000", reward_id = "708", extra_coins_percent = "200", picture = "shengji_vip_baijin.png"},
    ["5"] = {level = "5", alias = "diamond", vip_point = "100000", reward_id = "709", extra_coins_percent = "400", picture = "shengji_vip_zuanshi.png"}
}

    

