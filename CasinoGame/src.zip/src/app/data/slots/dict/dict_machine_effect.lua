--dict_machine_effect table
 
dict_machine_effect = {
    ["4"] = {machine_id = "4", explosion = "slots/slots_maya/effects/effect_shitou.ccbi"}
}

    

